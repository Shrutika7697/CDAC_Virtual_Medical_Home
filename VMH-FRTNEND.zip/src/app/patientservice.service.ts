import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
// export class PatientserviceService implements CanActivate {
export class PatientserviceService{

  /////////////for patient register/////////
  url = 'http://localhost:7070/patient';
     // ////////for get patient all details/////////
    // url2='http://localhost:7070/patient'

    // /////////for delete patient////////////
    // url3='http://localhost:7070/patient'

  urlForDateFilterApi = 'http://localhost:7070/slot/date/';
  urlForBooking = 'http://localhost:7070/appointment';
  urlForSlotUpdate ='http://localhost:7070/slot/';
  urlToGetAppointment ='http://localhost:7070/appointment';
  urlToUpdatePrescription = 'http://localhost:7070/appointment/prescription/';
  url1 = 'http://localhost:7070/patient/pname';

  ///////////////////////////get feedback by doc id//////////////////////////////////////
  urlToGetFeedback='http://localhost:7070/feedback';


  ///////////////////////////get patient history and prescription by patient id//////////////////////////////////////
  urlToGetPrescription='http://localhost:7070/appointment';




  //////////////////patient dashboard--to submit feedback by patient to particular doc id/////////////////////////
//-------------------------------------------------------//
urlToPostFeedback='http://localhost:7070/feedback';



 

  constructor(
    private router: Router,
    private httpClient: HttpClient) { }

    ////////////for patient register///////////////////////////////

  registerpatient(patientName: string, age: number, gender: string,
    weight: number, bloodgroup: string, address: string,
    patientemailID: string, contactno: number, ptntusername: string, ptntpassword: string): Observable<any> {
    const body = {

      patientName: patientName,
      age: age,
      gender: gender,
      weight: weight,                                                //postman
      bloodgroup: bloodgroup,
      address: address,
      patientemailID: patientemailID,
      contactno: contactno,
      ptntusername: ptntusername,
      ptntpassword: ptntpassword
    }
    return this.httpClient.post<any>(this.url + "/registerPtnt", body);
  }

  /////////////for patient login//////////////////////////////////////////////////
  loginpatient(ptntusername: string, ptntpassword: string): Observable<any> {
    const body = {

      ptntusername: ptntusername,                        //postman
      ptntpassword: ptntpassword

    }
    return this.httpClient.post<any>(this.url + "/login", body);
  }

  ////////////////////////////////////////////////////////////////////////

  //////////////////     NOTE: AUTH GUARD remaining    /////////////////////////////////////////////
  // canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
  //   if (sessionStorage['ptntusername']) {

  //     return true
  //   } else {
  //     this.router.navigate(['/login-as'])
  //     return false
  //   }
  // }
///////////////////////////// for patient dashboard///////////////////////////////////////////////
  getSlotsByDate(date){
    return this.httpClient.get(this.urlForDateFilterApi+date);
  }

  bookAppointment(data){
    
    return this.httpClient.post<any>(this.urlForBooking , data);
  }

  updateSlots(data,id){
    return this.httpClient.put<any>(this.urlForSlotUpdate+id, data);
  }

  ////////////////////////////////////////////////////////////////////////


  //////////////////   for doctor dashboard //////////////////////////////////
  getAppointments(){
    return this.httpClient.get(this.urlToGetAppointment);
  }

  updateAppointment(data, id){
    return this.httpClient.put<any>(this.urlToUpdatePrescription+id, data);
  }

  ////////////
  getFeedbacks(){
    return this.httpClient.get(this.urlToGetFeedback);
  }
  /////////////////////////////////////////////////////////////////////////

 ////////////at patient dashboard ----------get prescription by patient id////////////////////
 getPrescription(){
  return this.httpClient.get(this.urlToGetAppointment);
}

///////////////////////////////////////////////////////////////////////////////////////////////////

/////////////  view patient----------at admin dashboard//////////////////////////
  getpatient()
  {
 
  return this.httpClient.get(this.url);
 }
      
 /////////////  delete patient----------at admin dashboard//////////////////////////
   
 deletepatient(patientid){
   return this.httpClient.delete(this.url+"/"+patientid)                         //postman
 ///////////////////// NOTE:need to include one line to get refresh page after delete////////////////
 }
 

//---------------------------------------------------------------------------------//
 //////////// post feedback by patient////////////////////////////////////////////////////////
 postfeedback(feedbackDetails: string, rating: number, drid:number){
  const body = {
    feedbackDetails: feedbackDetails,
    rating: rating,   
    doctor:{
      drid:drid
    }                                 //postman
  }
  return this.httpClient.post(this.urlToPostFeedback, body);
}

//---------------------------------------------------------------------------------//

////////////////////////////search: get patient by name//////////////////////////////////////////////



searchpatient( patientName: string) {
  
  return this.httpClient.get(this.url1+'/'+  patientName);
}
}
