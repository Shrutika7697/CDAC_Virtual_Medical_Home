import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { CarouselModule } from 'ngx-owl-carousel-o';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';

import { MembershipModule } from './membership/membership.module';
import { PatientProfileModule } from './patient-profile/patient-profile.module';
import { AdminProfileModule} from './admin-profile/admin-profile.module';
import { DoctorProfileModule} from './doctor-profile/doctor-profile.module';

import {DoctorserviceService} from './doctorservice.service';
import {AdminserviceService} from './adminservice.service';
import {PatientserviceService} from './patientservice.service';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';




@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MembershipModule,
    PatientProfileModule,
    DoctorProfileModule,
    AdminProfileModule,
    CarouselModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()// ToastrModule added

  ],
  providers: [DoctorserviceService,AdminserviceService,PatientserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
