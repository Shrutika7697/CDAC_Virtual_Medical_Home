import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {AdminserviceService} from './../../adminservice.service';
import {NgForm} from '@angular/forms';


@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
username = '';
password = '';

 public uname;


constructor( 
  private router: Router,
  private adminService: AdminserviceService) { }

ngOnInit(): void {
   
  
}
/////////////////////////////////////////////////////////////////////////////////////////
    // onLoginAdmin(){
    //   alert("clicked")
    //   this.adminService
    //   .login(this.username, this.password,this.role)
    //   .subscribe(response => {
    //     console.log(response)
    //     if (response['status'] == 'success'){
    //         const data = response['data']


    //          sessionStorage['username'] = data['username']
    //          sessionStorage['password'] = data['password']
   
  
    //         this.router.navigate(['/admin-page'])
    //     }else{
    //       alert('invalid username or password')
    //     }
    //   }) 
  
    // }
    ////////////////////////////////////////////////////////////////////////////////////////////////

    //////////////////working///////////////////////
    // onLoginAdmin(){
    // this.adminService
  
    // .loginadmin(this.username, this.password)
  
    //   .subscribe(response=>
    //   {
    //     console.log(response)
    //   {
    //     alert("Admin Login Successfully...")
    //     this.router.navigate(['/admin-page'])
    //       const data =response['data']
    //       sessionStorage['username'] = data['username']
                  
    //            }
    //          }) 
    //        }


           /////////////////////////////////////////////////////////

           onLoginAdmin(){

           
            this.adminService
          
            .loginadmin(this.username, this.password)
          
              .subscribe(
                data=>{console.log("response received")

                console.log( 'admin data----------',data );
                sessionStorage['adminUsername']=data['adminUsername']
        
                alert("Admin Login Successfully...")
                this.router.navigate(['/admin-page'])
              
              }
                ,
                error=>{console.log("exception occured")
                 alert("Bad credentials, please enter valid username and password")
         
              
              }
        
              )
              this.uname=  `${sessionStorage['adminUsername']}`
              console.log(this.uname);
                   }

  ////////////////////////////////////////////////////////////////////////////
    // onLoginAdmin(){
    //   this.router.navigate(['/admin-page'])  

    // }
  }
  
