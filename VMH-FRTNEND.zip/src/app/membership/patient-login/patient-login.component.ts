import { Component, OnInit,Output,EventEmitter,SimpleChanges, Input } from '@angular/core';
import {PatientserviceService} from "../../patientservice.service";
import { Router } from '@angular/router';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-patient-login',
  templateUrl: './patient-login.component.html',
  styleUrls: ['./patient-login.component.css']
})
export class PatientLoginComponent implements OnInit {

  constructor(private router: Router,private pservice:PatientserviceService) { }

  username:string;
  password:string;
  msg='';
  public uname;

  ngOnInit(): void {
  }


  // onLoginPatient(){
  

  //   this.router.navigate(['/patient-page'])
  // }

////////////////////////////////////////////////////////////////
//////////////////working/////////////////////////
  // onLoginPatient(){
  //   this.pservice
  
  //   .loginpatient(this.username, this.password)
  
  //     .subscribe(response=>
  //     {
  //       console.log(response)
  //     {
  //       alert("Patient Login Successfully...")
  //       this.router.navigate(['/patient-page'])
  //         const data =response['data']
  //         sessionStorage['username'] = data['username']
                  
  //              }
  //            }) 
  //          }
  /////////////////////////////////////////////////////////////////////////
  onLoginPatient(){
    this.pservice
  
    .loginpatient(this.username, this.password)
  
      .subscribe(
        data=>{console.log("response received")
        console.log( 'patient data----------',data );
                sessionStorage['ptntusername']=data['ptntusername']
        console.log(data);
        localStorage.setItem("patientid",data.patientid);
        alert("Patient Login Successfully...")
        this.router.navigate(['/patient-page'])
      
      }
        ,
        error=>{console.log("exception occured")
         alert("Bad credentials, please enter valid username and password")
        
      //  this.msg="Bad credentials, please enter valid username and password";
      
      }

      )
      this.uname=  `${sessionStorage['ptntusername']}`
      console.log(this.uname);
           }

           gotoPatientRegister(){
            this.router.navigate(['/patient-form'])
           }


}
