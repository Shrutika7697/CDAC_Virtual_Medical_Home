import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule} from '@angular/common/http';
import { LoginAsComponent } from './login-as/login-as.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { DoctorLoginComponent } from './doctor-login/doctor-login.component';
import { PatientLoginComponent } from './patient-login/patient-login.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [LoginAsComponent, AdminLoginComponent, DoctorLoginComponent, PatientLoginComponent],
  imports: [
    CommonModule, FormsModule,
    HttpClientModule
  ],

  exports: [
    AdminLoginComponent,
    DoctorLoginComponent,
    PatientLoginComponent
  ]
})
export class MembershipModule { }
