import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-as',
  templateUrl: './login-as.component.html',
  styleUrls: ['./login-as.component.css']
})
export class LoginAsComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }


  onAdminClick(){
    this.router.navigate(['/admin-login'])
  }

  onDoctorClick(){
    this.router.navigate(['/doctor-login'])
  }
  onPatientClick(){
    this.router.navigate(['/patient-login'])
  }
}
