import { Component, OnInit,Output,EventEmitter,SimpleChanges, Input } from '@angular/core';
import {DoctorserviceService} from "../../doctorservice.service";
import { Router } from '@angular/router';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-doctor-login',
  templateUrl: './doctor-login.component.html',
  styleUrls: ['./doctor-login.component.css']
})
export class DoctorLoginComponent implements OnInit {

  constructor(private router: Router,private dservice:DoctorserviceService) { }

  username:string;
  password:string;

  public uname;
  ngOnInit(): void {

    
  }
  /////////////////////////////////////////////////////////////////////////////////////////
    // onLoginAdmin(){
    //   alert("clicked")
    //   this.adminService
    //   .login(this.username, this.password,this.role)
    //   .subscribe(response => {
    //     console.log(response)
    //     if (response['status'] == 'success'){
    //         const data = response['data']


    //          sessionStorage['username'] = data['username']
    //          sessionStorage['password'] = data['password']
   
  
    //         this.router.navigate(['/admin-page'])
    //     }else{
    //       alert('invalid username or password')
    //     }
    //   }) 
  
    // }
    ////////////////////////////////////////////////////////////////////////////////////////////////
  
  ///////////////////////////////working//////////////////////
  // onLoginDoctor(){
    
  //   this.dservice
  
  //   .logindoctor(this.username, this.password)
  
  //     .subscribe(response=>
  //     {
  //       console.log(response)
  //     {
  //       alert("Doctor Login Successfully...")
  //       this.router.navigate(['/doctor-page'])
  //         const data =response['data']
  //         sessionStorage['username'] = data['username']
                  
  //              }
  //            }) 
  //          }
///////////////////////////////////////////////////////////////////////////////////////////////////////
           onLoginDoctor(){
            this.dservice
          
            .logindoctor(this.username, this.password)
          
              .subscribe(
                data=>{console.log("response received")
                console.log( 'doctor data----------',data );
                sessionStorage['drusername']=data['drusername']
        
                localStorage.setItem("drid",data.drid);
                alert("Doctor Login Successfully...")
                this.router.navigate(['/doctor-page'])
              }
                ,
                error=>{console.log("exception occured")
                 alert("Bad credentials, please enter valid username and password")
              
              }
        
              )

              this.uname=  `${sessionStorage['drusername']}`
              console.log(this.uname);
                   }
        
  ///////////////////////////////////////////////////////////////////

  // onLoginDoctor(){
  //   this.router.navigate(['/doctor-page'])
  // }

}
