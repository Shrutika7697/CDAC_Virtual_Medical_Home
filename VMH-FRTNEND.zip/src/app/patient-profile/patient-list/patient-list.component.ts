import { Component, OnInit } from '@angular/core';
import {PatientserviceService} from "../../patientservice.service";
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-patient-list',
  templateUrl: './patient-list.component.html',
  styleUrls: ['./patient-list.component.css']
})
export class PatientListComponent implements OnInit {

  parr:any;
  pname:string;
  constructor(private router: Router,private pservice:PatientserviceService,private http:HttpClient,private toastr: ToastrService) { }

  ngOnInit(){


    this.parr=this.pservice.getpatient()
    .subscribe(

      data=>{this.parr=data
        console.log("response received")
        console.log(data)
      },
      error=>{console.log("exception occured")
       }
      
    );
  }

  onBack(){
    this.router.navigate(['/admin-page'])
  }

  onSearch(){
    this.pservice
    .searchpatient(this.pname)
    .subscribe(
      data=>{this.parr=[data]
        console.log("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
        console.log(data);
        console.log("response received")
        this.router.navigate(['patient-list'])
      },
      error=>{
        console.log("exception occured")
        this.toastr.warning('Error!', 'No Patient by this name!');
      }
    )
    
  }

}
