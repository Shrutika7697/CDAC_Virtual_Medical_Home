import { Component, OnInit } from '@angular/core';
import {PatientserviceService} from "../../patientservice.service";
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-patient-tab',
  templateUrl: './patient-tab.component.html',
  styleUrls: ['./patient-tab.component.css']
})
export class PatientTabComponent implements OnInit {
  parr:any; 
  constructor(private router: Router,private toastr: ToastrService,private dservice:PatientserviceService,private http:HttpClient) { }

  ngOnInit(){
    console.log("ngOnInit called in ptab")

    this.parr=this.dservice.getpatient()
    .subscribe(

      data=>{this.parr=data
        console.log("response received")
        console.log(data)
      },
      error=>{console.log("exception occured")
       }
      
    );
  }
  onBack(){
    this.router.navigate(['/admin-page'])
  }



  getPatient() {
    this.parr = this.dservice.getpatient()
      .subscribe(
        data => {
          this.parr = data
          console.log("response received")
          console.log(data)
        },
        error => {
          console.log("exception occured")
        }
      );
  }

  ondeletePatient(parr) {
    if (confirm("Are you sure to delete")) {
      console.log(parr['patientid'])
      this.dservice
        .deletepatient(parr['patientid'])
        .subscribe(
          data => {
            console.log("response received");
            this.toastr.warning('Done!', 'Successfully deleted!');
            this.getPatient();
          },
          error => {
            console.log("exception occured")
            alert("Patient is not removed")
          }
        )
    }
    // else {
    //   return;
    // }
  }

}
