import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { PatientserviceService } from 'src/app/patientservice.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-view-prescription',
  templateUrl: './view-prescription.component.html',
  styleUrls: ['./view-prescription.component.css']
})
export class ViewPrescriptionComponent implements OnInit {
  public prescriptions;

  constructor(private router: Router,private patientService: PatientserviceService,private toastr: ToastrService) { }


/////////////////////////////////////////////////////////////////////////////////////////////
  ngOnInit(): void {
    console.log(localStorage.getItem("patientid"));
    this.getFeedbacks();
  }

  filterArray(array, filters) {
    const filterKeys = Object.keys(filters);
    return array.filter(item => {
      // validates all filter criteria
      return filterKeys.every(key => {
        // ignores non-function predicates
        if (typeof filters[key] !== 'function') return true;
        return filters[key](item[key]);
      });
    });
  }

  getFeedbacks(){
    this.patientService.getPrescription()
    .subscribe(
      response => {
        //  debugger;
       
        var id =parseInt(localStorage.getItem("patientid"));
        const filters = {
          pAppointments: pAppointments => pAppointments.patientid == id
        };
        var filtered = this.filterArray(response, filters);
        this.prescriptions = filtered;
      },
      error => {
        console.log("exception occured")
      }
    );
  }

/////////////////////////////////////////////////////////////////////////////////////////////////




  onBack() {
    this.router.navigate(['/patient-page'])
  }
}
