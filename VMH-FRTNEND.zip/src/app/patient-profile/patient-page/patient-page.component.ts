import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {DoctorserviceService} from "../../doctorservice.service";


@Component({
  selector: 'app-patient-page',
  templateUrl: './patient-page.component.html',
  styleUrls: ['./patient-page.component.css']
})
export class PatientPageComponent implements OnInit {
  displayName;
  constructor(private router: Router) { }

  ngOnInit(): void {
    this.displayName = sessionStorage.getItem("ptntusername");
  }


  onViewDoctor(){
    this.router.navigate(['/view-doctor'])
  }
  
  onLogout() {
    if (confirm("Are you sure to logout")) {
      sessionStorage.removeItem("ptntusername");
      this.router.navigate(['']);  // /home
    } else {
      return;
    }
  }

  onViewPrescription(){
    this.router.navigate(['/view-prescription'])
  }

  onGiveFeedback(){
   
    this.router.navigate(['/give-feedback-form'])
  }


}
