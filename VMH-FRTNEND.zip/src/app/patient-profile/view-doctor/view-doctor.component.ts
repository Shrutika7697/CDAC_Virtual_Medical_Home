import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { DoctorserviceService } from 'src/app/doctorservice.service';
import { PatientserviceService } from 'src/app/patientservice.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-view-doctor',
  templateUrl: './view-doctor.component.html',
  styleUrls: ['./view-doctor.component.css']
})
export class ViewDoctorComponent implements OnInit {


public fmsg;
public frating;
public did;



  public doctors;
  public slots = [];
  public drid;
  public pid;
  public prescription;
  public illness;
  public datepickerModel;
  public slotname;
  bsValue = new Date();
  constructor(private toastr: ToastrService,private dservice: DoctorserviceService, private router: Router, private patientService: PatientserviceService) { }

  ngOnInit(): void {
    this.getDoctors();
  }
  populateDetails(d) {
    this.drid = d.drid;
    this.pid = localStorage.getItem("patientid");
    
  }

  onBack() {
    this.router.navigate(['/patient-page'])
  }


  book(bookingForm: NgForm) {
    // debugger;
    var updateSlotObj = {
      "slotstatus": "NOT_AVAILABLE"
    };
    var slotid = parseInt(bookingForm.controls['slotname'].value);
    console.log(updateSlotObj);
    console.log("yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy");
    this.patientService.updateSlots(updateSlotObj, slotid).subscribe(
      response => {
        // console.log(response);
        //////////////////////////for post the feedback/////////////////////////////
        console.log("thisssssssssssssssssssssssssssss", response);      
        console.log( response['doctorSlots']['drid'] );
             sessionStorage['drid']=response['doctorSlots']['drid']
             /////////////////////////////////////////////////////////
        this.getDoctors();
      },
      error => {
        console.log(error);
      }
    );

    var bookingObject = {
      "doctorAptmnts": {
        "drid": this.drid,
      },
      "pAppointments": {
        "patientid": this.pid,
      },
      "illness": bookingForm.controls['illness'].value
    };
    console.log(bookingObject);
    this.patientService.bookAppointment(bookingObject).subscribe(
      response => {
        console.log(response);
console.log("hereeeeeeeeeeeeeeeeeeeeeeeeeee");

        this.getDoctors();
        this.toastr.success('Appointment booked for selected slot time!, now View Prescription and then Give Feedback','Done!');
      },
      error => {
        console.log(error);
      }
    );
  }

  filterArray(array, filters) {
    const filterKeys = Object.keys(filters);
    return array.filter(item => {
      // validates all filter criteria
      return filterKeys.every(key => {
        // ignores non-function predicates
        if (typeof filters[key] !== 'function') return true;
        return filters[key](item[key]);
      });
    });
  }

  handleChange(e) {
    console.log(e.target.value);
    var selectedDate = e.target.value;
    if (selectedDate == null) {
      selectedDate = new Date();
      console.log("todays date" + selectedDate);
    }
    this.patientService.getSlotsByDate(selectedDate)
      .subscribe(
        (response) => {
          const filters = {
            doctorSlots: doctorSlots => doctorSlots.drid == this.drid
          };
          var filtered = this.filterArray(response, filters);
          this.slots = filtered;

        },
        error => {
          console.log("exception occured while getting slots")
        }
      );
  }

  getDoctors() {
    this.doctors = this.dservice.getdoctor()
      .subscribe(
        response => {
          this.doctors = response;
          console.log(response);
          console.log("pppppppppppppppppppppppppppppppppppppp");

        },
        error => {
          console.log("exception occured");
          this.toastr.warning('Error!', 'Did not recieve data');
        }
      );
  }


////////////////////////////////////add feedback//////////////////////////////////////////////////////////////////
  
addfeedback(fregisterform: NgForm) {

  this.did=  `${sessionStorage['drid']}`
  console.log('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww',this.did);

  this.patientService 
    .postfeedback(this.fmsg,this.frating,this.did)
    .subscribe(
      data => {
        console.log("response received")
        this.router.navigate(['/view-doctor']),

        this.toastr.success('Done!', 'feedback submitted successfully!');
      },
      error => {
        console.log("exception occured")
        this.toastr.warning('Error!');
      }
    )
}
}

