import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatientFormComponent } from './patient-form/patient-form.component';
import { PatientListComponent } from './patient-list/patient-list.component';
import { PatientTabComponent } from './patient-tab/patient-tab.component';
import { PatientPageComponent } from './patient-page/patient-page.component';
import { FormsModule } from '@angular/forms';
import { ViewDoctorComponent } from './view-doctor/view-doctor.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { PatientAppointmentComponent } from './patient-appointment/patient-appointment.component';
import { HttpClientModule } from '@angular/common/http';
import { ViewPrescriptionComponent } from './view-prescription/view-prescription.component';


@NgModule({
  declarations: [PatientFormComponent, PatientListComponent, PatientTabComponent, PatientPageComponent, ViewDoctorComponent, PatientAppointmentComponent,
     ViewPrescriptionComponent],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    BsDatepickerModule.forRoot(),
  ],

  exports: [
    PatientFormComponent, PatientListComponent, PatientTabComponent, PatientPageComponent,ViewDoctorComponent,ViewPrescriptionComponent,
  
  ]
})
export class PatientProfileModule { }
