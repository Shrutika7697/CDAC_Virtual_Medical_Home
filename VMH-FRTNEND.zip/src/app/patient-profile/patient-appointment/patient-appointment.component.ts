import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PatientserviceService } from 'src/app/patientservice.service';

@Component({
  selector: 'app-patient-appointment',
  templateUrl: './patient-appointment.component.html',
  styleUrls: ['./patient-appointment.component.css']
})
export class PatientAppointmentComponent implements OnInit {
  public appointments;
  constructor(private router: Router,  private patientService: PatientserviceService) { }

  ngOnInit(): void {
    this.getAppointments();
  }

  getAppointments(){
    this.patientService.getAppointments()
    .subscribe(
      response => {
        this.appointments = response;
        console.log("appointments"+this.appointments);
      },
      error => {
        console.log("exception occured")
      }
    );
  }

  onBack() {
    this.router.navigate(['/patient-page'])
  }
}
