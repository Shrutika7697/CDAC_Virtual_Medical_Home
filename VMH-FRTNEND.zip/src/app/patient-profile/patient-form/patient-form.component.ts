import { Component, OnInit,Output,EventEmitter,SimpleChanges, Input } from '@angular/core';
import {PatientserviceService} from "../../patientservice.service";
import { Router } from '@angular/router';
import {NgForm} from '@angular/forms';


@Component({
  selector: 'app-patient-form',
  templateUrl: './patient-form.component.html',
  styleUrls: ['./patient-form.component.css']
})
export class PatientFormComponent implements OnInit {


  constructor(private router: Router,private pservice:PatientserviceService){}


// "patientid": 1,
      // "patientName": "Rani",
      // "age": 25,
      // "gender": "FEMALE",
      // "weight": 50.0,
      // "bloodgroup": "A positive",
      // "address": "mumbai",
      // "patientemailID": "rani@gmail.com",
      // "contactno": 1234567890,
      // "ptntusername": "rani",
      // "ptntpassword": "rani",

  pname:string;
  page=0;
  pgender:string;
  pweight:number;
  pbldgrp:string;
  paddress:string;
  pemail:string;
  pcontact:number;
  puname:string;
  ppswd:string;

  ngOnInit(): void {
  }
////////////////////////////////////////////////////////////////////
//////////////////working/////////////////////////////////////  
  onPatientRegister(){
    this.pservice
  
    .registerpatient(this.pname,this.page,this.pgender,this.pweight,this.pbldgrp,this.paddress,
      this.pemail,this.pcontact,this.puname,this.ppswd)
  
      .subscribe(
      
       data=>{ 
        console.log("response received")
        alert("Patient Registered Successfully...")
        this.router.navigate(['/patient-login'])
        
          sessionStorage['pname'] = data['pname']
       },
       error=>{console.log("exception occured")
              alert("Patient already exists!!!")
             }
      )
    }
  }

      
        
          // const data =response['data']
          // sessionStorage['pname'] = data['pname']



//////////////////////////////////////////////////////////////////////////////////////
          //  onPatientRegister(){
          //   this.pservice
          
          //   .loginpatient(this.username, this.password)
          
          //     .subscribe(
          //       data=>{console.log("response received")
        
          //       alert("Patient Login Successfully...")
          //       this.router.navigate(['/patient-page'])
              
          //     }
          //       ,
          //       error=>{console.log("exception occured")
          //        alert("Bad credentials, please enter valid username and password")
                
          //     //  this.msg="Bad credentials, please enter valid username and password";
              
          //     }
        
          //     )
          //          }
