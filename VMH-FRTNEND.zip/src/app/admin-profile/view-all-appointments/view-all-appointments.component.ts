import { Component, OnInit } from '@angular/core';
import {AdminserviceService} from './../../adminservice.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-view-all-appointments',
  templateUrl: './view-all-appointments.component.html',
  styleUrls: ['./view-all-appointments.component.css']
})
export class ViewAllAppointmentsComponent implements OnInit {
  aarr:any;
  constructor(private router: Router,private aservice:AdminserviceService,private http:HttpClient) { }

  

  ngOnInit(){
    
    this.aarr=this.aservice.getallappointment()
    .subscribe(

      data=>{this.aarr=data
        console.log("response received")
        console.log(data)
      },
      error=>{console.log("exception occured")
       }
      
    );
}



onBack(){
  this.router.navigate(['/admin-page'])
}

}
