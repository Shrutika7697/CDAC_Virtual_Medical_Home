import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-admin-page',
  templateUrl: './admin-page.component.html',
  styleUrls: ['./admin-page.component.css']
})
export class AdminPageComponent implements OnInit {
  displayName;
  adminUsername:string;

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.displayName = sessionStorage.getItem("adminUsername");
  }
  onViewPatient(){

    this.router.navigate(['/patient-list'])
  }
  onManageDoctor(){
    this.router.navigate(['/doctor-tab'])
  }
  onManagePatient(){
    this.router.navigate(['/patient-tab'])
  }

  onRegisterDoctor(){
    this.router.navigate(['/doctor-form'])
  }
  onViewDoctor(){
    this.router.navigate(['/doctor-list'])
  }

  OnViewAllAppointment(){
    this.router.navigate(['/view-all-appointments'])
  }

  OnViewAllFeedback(){
    this.router.navigate(['/view-all-feedbacks'])
  }
  onLogout() {
    if (confirm("Are you sure to logout")) {
      sessionStorage.removeItem('adminUsername');
      this.router.navigate(['']);
    } else {
      return;
    }
  }

  

}


