import { Component, OnInit } from '@angular/core';
import {AdminserviceService} from './../../adminservice.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-view-all-feedback',
  templateUrl: './view-all-feedback.component.html',
  styleUrls: ['./view-all-feedback.component.css']
})
export class ViewAllFeedbackComponent implements OnInit {
  farr:any;
  constructor(private router: Router,private fservice:AdminserviceService,private http:HttpClient) { }


  ngOnInit(){
    
    this.farr=this.fservice.getallfeedback()
    .subscribe(

      data=>{this.farr=data
        console.log("response received")
        console.log(data)
      },
      error=>{console.log("exception occured")
       }
      
    );
}



onBack(){
  this.router.navigate(['/admin-page'])
}
}
