import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { ViewAllAppointmentsComponent } from './view-all-appointments/view-all-appointments.component';
import { ViewAllFeedbackComponent } from './view-all-feedback/view-all-feedback.component';



@NgModule({
  declarations: [AdminPageComponent, ViewAllAppointmentsComponent, ViewAllFeedbackComponent],
  imports: [
    CommonModule
  ]
})
export class AdminProfileModule { }
