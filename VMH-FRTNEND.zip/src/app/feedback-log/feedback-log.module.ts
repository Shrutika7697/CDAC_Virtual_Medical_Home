import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FeedbackFormComponent } from './feedback-form/feedback-form.component';
import { FeedbackListComponent } from './feedback-list/feedback-list.component';



@NgModule({
  declarations: [FeedbackFormComponent, FeedbackListComponent],
  imports: [
    CommonModule
  ]
})
export class FeedbackLogModule { }
