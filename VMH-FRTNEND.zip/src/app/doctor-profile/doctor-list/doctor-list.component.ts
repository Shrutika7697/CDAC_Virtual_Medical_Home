import { Component, OnInit } from '@angular/core';
import {DoctorserviceService} from "../../doctorservice.service";
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-doctor-list',
  templateUrl: './doctor-list.component.html',
  styleUrls: ['./doctor-list.component.css']
})
export class DoctorListComponent implements OnInit {
  darr:any;
  constructor(private router: Router,private dservice:DoctorserviceService,private http:HttpClient,private toastr: ToastrService) { }
  dcharges=0;
  ddesig:string;
  dname:string;
 
  demail:string;
  
  dexp:string;
  dgender:string;
  dspecial:number;
  search:string;


  ngOnInit(){
    
    this.darr=this.dservice.getdoctor()
    .subscribe(

      data=>{this.darr=data
        console.log("response received")
        console.log(data)
      },
      error=>{console.log("exception occured")
       }
      
    );
}



onBack(){
  this.router.navigate(['/admin-page'])
}

onSearch(){
  this.dservice
  .searchdoctor(this.dname)
  .subscribe(
    
    data=>{this.darr=[data]
      console.log(this.darr);
      console.log("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
      console.log(data);
      console.log("response received")
      this.router.navigate(['doctor-list'])
    },
    error=>{
      console.log("exception occured")
      this.toastr.warning('Error!', 'No Doctor by this name!');
    }
  )
  
}



}
