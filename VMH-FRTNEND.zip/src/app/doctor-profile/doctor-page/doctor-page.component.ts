import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doctor-page',
  templateUrl: './doctor-page.component.html',
  styleUrls: ['./doctor-page.component.css']
})
export class DoctorPageComponent implements OnInit {
  displayName;
  constructor(private router: Router) { }

  ngOnInit(): void {
    this.displayName = sessionStorage.getItem("drusername");
  }

  onViewAppointments(){
    this.router.navigate(['/view-appointment']);
  }

  onViewFeedback(){
    this.router.navigate(['/view-feedback']);
  }

  onLogout() {
    if (confirm("Are you sure to logout")) {
      sessionStorage.removeItem("drusername");
      this.router.navigate([''])   // /home
    } else {
      return;
    }
  }

}

