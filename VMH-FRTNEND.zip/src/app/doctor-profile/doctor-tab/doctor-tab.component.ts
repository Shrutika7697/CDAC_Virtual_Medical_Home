import { Component, OnInit } from '@angular/core';
import { DoctorserviceService } from "../../doctorservice.service";
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-doctor-tab',
  templateUrl: './doctor-tab.component.html',

  styleUrls: ['./doctor-tab.component.css']
})
export class DoctorTabComponent implements OnInit {
  darr: any;
  public dname;
  public dgender;
  public demail;
  public dexp;
  public dcharges;
  public dspecial;
  public ddesig;
  public duname;
  public dpswd;
  public drid;


  constructor(private router: Router,private toastr: ToastrService, private dservice: DoctorserviceService, private http: HttpClient) { }

  ngOnInit() {  
    this.getDoctors();
  }

  prepareToUpdateDoctor(data) {   
    this.dname = data.drName;
    this.dgender = data.gender;
    this.demail = data.emailID;
    this.dexp = data.experience;
    this.dcharges = data.consultationCost;
    this.dspecial = data.specializtnDr.specializationId;
    this.ddesig = data.designation;
    this.duname = data.drusername;
    this.dpswd = data.drpassword;
    this.drid = data.drid;
  }

  
  updateDoctor(dregisterform: NgForm) {   
    var object = {
      "drName": this.dname,
      "gender": this.dgender,
      "emailID": this.demail,
      "experience": this.dexp,
      "designation": this.ddesig,
      "consultationCost": this.dcharges,     
      "drusername": this.duname,
      "drpassword": this.dpswd,
      "drid": parseInt(this.drid),
      "specializtnDr": {
        "specializationId": this.dspecial,
      }
    };
    this.dservice.updateDoctor(object).subscribe(
      response =>
      {
        console.log(response);
        this.getDoctors();
        this.darr = response;
        this.toastr.success('Done!', 'Successfully updated!');
      },
      error => {
        console.log(error);
      }
    );
  }

  getDoctors() {
    this.darr = this.dservice.getdoctor()
      .subscribe(
        data => {
          this.darr = data
          console.log("response received")
          console.log(data)
        },
        error => {
          console.log("exception occured")
        }
      );
  }


  ////////////////////back button done//////////////////////////////////
  onBack() {
    this.router.navigate(['/admin-page'])
  }
  ////////////////////////////////////////////////////////////////////////////////
  ////////////delete done//////////////////////////////

  ondeleteDoctor(darr) {
    if (confirm("Are you sure to delete")) {
      console.log(darr['drid'])
      this.dservice
        .deletedoctor(darr['drid'])
        .subscribe(
          data => {
            console.log("response received");
            this.toastr.warning('Done!', 'Successfully deleted!');
            this.getDoctors();
          },
          error => {
            console.log("exception occured")
            alert("Doctor is not removed")
          }
        )
    }
    // else {
    //   return;
    // }
  }

  /////////////////////////////////////////////////////////////////// 

}
