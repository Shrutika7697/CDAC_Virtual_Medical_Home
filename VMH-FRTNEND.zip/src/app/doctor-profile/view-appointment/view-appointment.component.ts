import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { PatientserviceService } from 'src/app/patientservice.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-view-appointment',
  templateUrl: './view-appointment.component.html',
  styleUrls: ['./view-appointment.component.css']
})
export class ViewAppointmentComponent implements OnInit {
  public appointments;
  public prescription;
  public appointmentId;
  //////////////////////////////////////
  public count=0;
  ///////////////////////////////////////
  constructor(private router: Router,private patientService: PatientserviceService,private toastr: ToastrService) { }

  ngOnInit(): void {
    console.log(localStorage.getItem("drid"));
    this.getAppointments();
  }

  filterArray(array, filters) {
    const filterKeys = Object.keys(filters);
    return array.filter(item => {
      // validates all filter criteria
      return filterKeys.every(key => {
        // ignores non-function predicates
        if (typeof filters[key] !== 'function') return true;
        return filters[key](item[key]);
      });
    });
  }

  getAppointments(){
    this.patientService.getAppointments()
    .subscribe(
      response => {
        // debugger;
        var id =parseInt(localStorage.getItem("drid"));
        const filters = {
          doctorAptmnts: doctorAptmnts => doctorAptmnts.drid == id
        };
        var filtered = this.filterArray(response, filters);
        this.appointments = filtered;
      },
      error => {
        console.log("exception occured")
      }
    );
  }

  onBack() {
    this.router.navigate(['/doctor-page'])
  }

  prepareForUpdate(data){
    this.appointmentId = data.appointmentid;
  }

  addPrescription(prescriptionform: NgForm) {

    // if(this.count==0)
    //       {
            // debugger;
                  var updateObj = {
                    "prescriptions": prescriptionform.controls['prescription'].value
                   };
                       this.patientService.updateAppointment(updateObj, this.appointmentId).subscribe
                       (
                   response => {
                    console.log(response);
                   this.getAppointments();
                    this.toastr.success('Done!', 'Prescribed Medicine Success !');
                    this.count++;
                    console.log("thisssssssssssssssssssss",this.count);

                   },
                      error => {
                     console.log(error);
                       this.toastr.warning('Try again!', 'Failed to update !');
                       }
                   );
  
            }
        //   else{
        // this.toastr.warning('Patient is already prescribed');
        // this.count--;
        //  }
    

  }


