import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { PatientserviceService } from 'src/app/patientservice.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-view-feedback',
  templateUrl: './view-feedback.component.html',
  styleUrls: ['./view-feedback.component.css']
})
export class ViewFeedbackComponent implements OnInit {
  public feedbacks;

  constructor(private router: Router,private patientService: PatientserviceService,private toastr: ToastrService) { }

  /////////////////////////////////////////////////////////////////////////////////////
  ngOnInit(): void {
    console.log(localStorage.getItem("drid"));
    this.getFeedbacks();
  }

  filterArray(array, filters) {
    const filterKeys = Object.keys(filters);
    return array.filter(item => {
      // validates all filter criteria
      return filterKeys.every(key => {
        // ignores non-function predicates
        if (typeof filters[key] !== 'function') return true;
        return filters[key](item[key]);
      });
    });
  }

  getFeedbacks(){
    this.patientService.getFeedbacks()
    .subscribe(
      response => {
        //  debugger;
       
        var id =parseInt(localStorage.getItem("drid"));
        const filters = {
          doctor: doctor => doctor.drid == id
        };
        var filtered = this.filterArray(response, filters);
        this.feedbacks = filtered;
      },
      error => {
        console.log("exception occured")
      }
    );
  }

/////////////////////////////////////////////////////////////////////////////////////////////////




  onBack() {
    this.router.navigate(['/doctor-page'])
  }
}
