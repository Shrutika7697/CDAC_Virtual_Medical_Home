import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import {HomeComponent} from './home/home.component';
import {LoginAsComponent} from './membership/login-as/login-as.component';

import {AdminLoginComponent} from './membership/admin-login/admin-login.component';
import {DoctorLoginComponent} from './membership/doctor-login/doctor-login.component';
import {PatientLoginComponent} from './membership/patient-login/patient-login.component';



import {PatientFormComponent} from './patient-profile/patient-form/patient-form.component';
import {PatientListComponent} from './patient-profile/patient-list/patient-list.component';
import {PatientTabComponent} from './patient-profile/patient-tab/patient-tab.component';

///////////patient, view doctor, enter illness and book appointment/////////////////////
import {ViewDoctorComponent } from "./patient-profile/view-doctor/view-doctor.component";
import {PatientAppointmentComponent } from "./patient-profile/patient-appointment/patient-appointment.component";
import {ViewPrescriptionComponent} from "./patient-profile/view-prescription/view-prescription.component";



import {PatientPageComponent} from './patient-profile/patient-page/patient-page.component';
import {AdminPageComponent} from './admin-profile/admin-page/admin-page.component';
import {DoctorPageComponent} from './doctor-profile/doctor-page/doctor-page.component';


//////////////admin dashboard///////////////////////////////////////////////////////////////
import {ViewAllAppointmentsComponent} from './admin-profile/view-all-appointments/view-all-appointments.component'; 
import {ViewAllFeedbackComponent} from './admin-profile/view-all-feedback/view-all-feedback.component';

import {DoctorFormComponent} from './doctor-profile/doctor-form/doctor-form.component';
import {DoctorListComponent} from './doctor-profile/doctor-list/doctor-list.component';
import {DoctorTabComponent} from './doctor-profile/doctor-tab/doctor-tab.component';

//////////////////doctor dashboard////////////////////////
////////////doctor view appointment request and give prescription //////////////////////
import {ViewAppointmentComponent } from "./doctor-profile/view-appointment/view-appointment.component";
////////////doctor view feedback /////////////////////////////////////////////////////
import {ViewFeedbackComponent } from "./doctor-profile/view-feedback/view-feedback.component";
import { AdminGuard } from './admin.guard';
import { DoctorGuard } from './doctor.guard';
import { PatientGuard } from './patient.guard';

const routes: Routes = [
{ path: 'about', component: AboutComponent },
{ path: 'contact', component: ContactComponent },
{path: '',component:HomeComponent},
{path: 'login-as',component:LoginAsComponent},


{path:'admin-login',component:AdminLoginComponent},
{path:'doctor-login',component:DoctorLoginComponent},
{path:'patient-login',component:PatientLoginComponent},


{path:'patient-page',component:PatientPageComponent, canActivate :[PatientGuard]},
{path:'admin-page',component:AdminPageComponent, canActivate :[AdminGuard]},
{path:'doctor-page',component:DoctorPageComponent, canActivate :[DoctorGuard]},

//////////////////////////////////////////////////////////admin page view all appointments details
{path:'view-all-appointments',component:ViewAllAppointmentsComponent, canActivate :[AdminGuard]},
/////////////////////////////////////////////////////////admin page view all feedbacks
{path:'view-all-feedbacks',component:ViewAllFeedbackComponent, canActivate :[AdminGuard]},

{path:'patient-form',component:PatientFormComponent}, //, canActivate :[PatientGuard]
{path:'patient-list',component:PatientListComponent, canActivate :[AdminGuard]}, 
{path:'patient-tab',component:PatientTabComponent, canActivate :[AdminGuard]},  
{path:'view-doctor',component:ViewDoctorComponent, canActivate :[PatientGuard]},             //view all doctor, select, give illness, book appointment
{path:'patient-appointment',component:PatientAppointmentComponent, canActivate :[PatientGuard]},
                                                                   //give feedback
{path:'view-prescription',component:ViewPrescriptionComponent, canActivate :[PatientGuard]},  //view prescription and history----by pt id
                                                                

{path:'doctor-form',component:DoctorFormComponent, canActivate :[AdminGuard]},
{path:'doctor-list',component:DoctorListComponent, canActivate :[AdminGuard]}, 
{path:'doctor-tab',component:DoctorTabComponent, canActivate :[AdminGuard]}, 
{path:'view-appointment', component:ViewAppointmentComponent, canActivate :[DoctorGuard]},         //view appointment request and give prescription
{path:'view-feedback', component:ViewFeedbackComponent, canActivate :[DoctorGuard]}               ///view doctor feedback as per doc id

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
