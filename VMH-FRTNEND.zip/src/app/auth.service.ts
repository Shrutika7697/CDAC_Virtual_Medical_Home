import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  public isLoggedInAdmin() {
    console.log(sessionStorage.getItem('adminUsername'));
    return sessionStorage.getItem('adminUsername') !== null;    
  }

  public isLoggedInDoctor() {
    console.log(sessionStorage.getItem('drusername'));
    return sessionStorage.getItem('drusername') !== null;    
  }

  public isLoggedInPatient() {
    console.log(sessionStorage.getItem('ptntusername'));
    return sessionStorage.getItem('ptntusername') !== null;    
  }
  
}
