import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
  
})
// export class AdminserviceService  implements CanActivate {
  export class AdminserviceService  {

  url = 'http://localhost:7070/admin/login'

  url1 ='http://localhost:7070/appointment'

  url2 ='http://localhost:7070/feedback'

 
  constructor(
    private router: Router, 
    private httpClient: HttpClient) { }


  loginadmin( adminUsername:string,adminPassword:string):Observable<any>
  {
    const body = {
   
      adminUsername:adminUsername,
      adminPassword:adminPassword                                                 //postman
     
    }
    return this.httpClient.post<any>(this.url, body);
  }


  /////////////////////////////get appointment////////////////////////
  getallappointment() {
    return this.httpClient.get(this.url1);
  }

  /////////////////////////////get appointment////////////////////////
  getallfeedback() {
    return this.httpClient.get(this.url2);
  }
 

  // canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
  //   if(sessionStorage[' adminUsername']){   
     
  //     return true
  //   }else{
  //     this.router.navigate(['/login-as'])
  //     return false
  //   }
  // }
}


